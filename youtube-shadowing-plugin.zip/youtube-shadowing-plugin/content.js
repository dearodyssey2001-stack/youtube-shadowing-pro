let video;
let checkInterval;
let lastMarkTime = 0;

// 初始化面板
function init() {
    if (document.getElementById('shadow-study-tool')) return;
    video = document.querySelector('video');
    if (!video) {
        setTimeout(init, 2000); // 如果还没加载出视频，2秒后重试
        return;
    }

    const panel = document.createElement('div');
    panel.id = 'shadow-study-tool';
    panel.innerHTML = `
        <div class="panel-header"><h3>🎧 影子跟读大师</h3></div>
        <div class="control-zone">
            <button id="mark-btn">记录当前句子 (Space/Enter)</button>
            <div style="margin-top:8px; font-size:11px; color:#888; text-align:center;">
                听到句子结束按下，记录刚才那段
            </div>
        </div>
        <div class="sub-container" id="sub-list"></div>
    `;
    document.body.appendChild(panel);

    document.getElementById('mark-btn').onclick = manualCut;
    
    // 监听键盘：空格或回车断句
    window.addEventListener('keydown', (e) => {
        if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
            if (e.code === 'Space' || e.code === 'Enter') {
                e.preventDefault();
                manualCut();
            }
        }
    });

    lastMarkTime = video.currentTime;
}

// 断句逻辑
function manualCut() {
    const currentTime = video.currentTime;
    const segs = document.querySelectorAll('.ytp-caption-segment');
    const text = Array.from(segs).map(s => s.innerText.trim()).join(' ') || "(未捕获到字幕)";
    const startTime = lastMarkTime;
    const endTime = currentTime;

    if (endTime <= startTime + 0.2) return;

    addSentenceCard(text, startTime, endTime);
    lastMarkTime = currentTime;
}

// 创建句子卡片
function addSentenceCard(text, start, end) {
    const list = document.getElementById('sub-list');
    const item = document.createElement('div');
    item.className = 'sub-item';
    
    item.innerHTML = `
        <span class="time-box">${formatTime(start)} - ${formatTime(end)}</span>
        <div class="text-content">${text}</div>
        <div style="display:flex; gap:8px; align-items:center;">
            <button class="record-btn">🎤 按住跟读</button>
            <span class="recording-ui">● 录音中</span>
            <button class="compare-play-btn" style="display:none;">🔈 原音+我的</button>
        </div>
    `;

    let mediaRecorder;
    let chunks = [];
    let userAudioUrl = null;
    const recordBtn = item.querySelector('.record-btn');
    const compareBtn = item.querySelector('.compare-play-btn');
    const recordingUI = item.querySelector('.recording-ui');

    // 录音按住逻辑
    recordBtn.onmousedown = async (e) => {
        e.stopPropagation();
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaRecorder = new MediaRecorder(stream);
            chunks = [];

            mediaRecorder.ondataavailable = (e) => {
                if (e.data.size > 0) chunks.push(e.data);
            };

            mediaRecorder.onstop = () => {
                const blob = new Blob(chunks, { type: 'audio/webm' });
                if (blob.size > 0) {
                    userAudioUrl = URL.createObjectURL(blob);
                    compareBtn.style.display = 'inline-block';
                }
                stream.getTracks().forEach(t => t.stop()); // 释放麦克风
            };

            mediaRecorder.start();
            recordBtn.style.background = "#ff4444";
            recordingUI.style.display = "inline";
        } catch (err) {
            alert("无法访问麦克风，请检查浏览器权限设置！");
        }
    };

    recordBtn.onmouseup = (e) => {
        e.stopPropagation();
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
            recordBtn.style.background = "#444";
            recordingUI.style.display = "none";
        }
    };

    // 对比播放逻辑
    compareBtn.onclick = (e) => {
        e.stopPropagation();
        if (!userAudioUrl) return;

        // 先播放原视频
        video.currentTime = start;
        video.play();

        const checker = setInterval(() => {
            if (video.currentTime >= end) {
                video.pause();
                clearInterval(checker);
                // 接着播放用户录音
                const audio = new Audio(userAudioUrl);
                audio.play();
            }
        }, 50);
    };

    // 单击卡片只放原音
    item.onclick = () => playSegment(start, end);
    
    list.insertBefore(item, list.firstChild);
}

function playSegment(start, end) {
    video.currentTime = start;
    video.play();
    if (checkInterval) clearInterval(checkInterval);
    checkInterval = setInterval(() => {
        if (video.currentTime >= end) {
            video.pause();
            clearInterval(checkInterval);
        }
    }, 50);
}

function formatTime(s) {
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec < 10 ? '0' + sec : sec}`;
}

// 启动
setTimeout(init, 3000);